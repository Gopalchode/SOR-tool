Welcome to SOR TOOL.....

1. Extract the SOR Tool folder in your system from the SOR TOOL zip file.
2. Click enable editing and enable content.
3. Using browse and upload option upload the respective input files like SOR payment file, Invoice issue's doc, UNDEF VAT code file.
4. Please enter the inputs,for example, a valid wire number or a valid wire amount and click the respective button.
5. The wire number always contain a prefix of four zeroes. For example: "00005833/2".
6. If there are more than one vendor name for a wire amount or wire number, the ouput sheet will be popped up with the remittance details for all the vendors. So you can choose the respective wire number from the output sheet and enter the wire number in the remittance generator to get the respective remittance details.
7. You can enter the PO number to check whether the respective PO number have undef vat codes issue to invoice issue(also you can use the invoice number for finding invoice issues).



